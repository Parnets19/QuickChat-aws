module.exports = {
  apps: [{
    name: 'server',
    script: '/home/ubuntu/QuickChat-aws/src/server.js',
    cwd: '/home/ubuntu/QuickChat-aws',
    env: {
      NODE_ENV: 'production',
      PORT: '5001',
      PHONEPE_ENV: 'production',
      PHONEPE_CLIENT_ID: 'SU2602271710223361427734',
      PHONEPE_CLIENT_SECRET: 'a0755144-e7c6-4e0d-a71f-42681b4faf0b',
      PHONEPE_CLIENT_VERSION: '1',
      PHONEPE_MERCHANT_ID: 'M2352B2GR2M1V',
      PHONEPE_CALLBACK_URL: 'https://quickchatindia.com',
      BACKEND_URL: 'https://quickchatindia.com',
      PHONEPE_SECRET_KEY: 'a0755144-e7c6-4e0d-a71f-42681b4faf0b'
    }
  }]
};

module.exports = {
  apps: [{
    name: 'server',
    script: 'src/server.js',
    cwd: './',
    env: {
      NODE_ENV: 'development',
      PORT: '5001',
    }
  }]
};