const admin = require('firebase-admin');
const { logger } = require('./logger');
const path = require('path');
const fs = require('fs');

let firebaseInitialized = false;

// Initialize Firebase Admin only if credentials are provided
if (!admin.apps.length) {
  let firebaseConfig;
  
  // Try to load from service_account.json file first
  const serviceAccountPath = path.join(__dirname, '../../service_account.json');
  
  if (fs.existsSync(serviceAccountPath)) {
    try {
      const serviceAccount = require(serviceAccountPath);
      firebaseConfig = {
        credential: admin.credential.cert(serviceAccount)
      };
      logger.info('Firebase initialized using service_account.json file');
    } catch (error) {
      logger.error('Error loading service_account.json:', error.message);
    }
  }
  
  // Fallback to environment variables if file not found or failed
  if (!firebaseConfig) {
    const envConfig = {
      projectId: process.env.FIREBASE_PROJECT_ID,
      privateKey: process.env.FIREBASE_PRIVATE_KEY?.replace(/\\n/g, '\n'),
      clientEmail: process.env.FIREBASE_CLIENT_EMAIL,
    };

    // Check if all required Firebase credentials are provided
    if (envConfig.projectId && envConfig.privateKey && envConfig.clientEmail) {
      firebaseConfig = {
        credential: admin.credential.cert(envConfig)
      };
      logger.info('Firebase initialized using environment variables');
    } else {
      logger.warn('Firebase credentials not found. Push notification functionality will be disabled.');
    }
  }

  // Initialize Firebase if config is available
  if (firebaseConfig) {
    try {
      admin.initializeApp(firebaseConfig);
      firebaseInitialized = true;
      logger.info('Firebase Admin initialized successfully');
    } catch (error) {
      logger.error('Firebase initialization error:', error.message);
      firebaseInitialized = false;
    }
  }
}

const sendPushNotification = async (notification) => {
  if (!firebaseInitialized) {
    console.warn('⚠️ Firebase not initialized. Skipping push notification.');
    return { success: false, error: 'Firebase not initialized' };
  }

  try {
    console.log('📤 Preparing to send push notification:', {
      title: notification.title,
      body: notification.body?.substring(0, 50),
      hasToken: !!notification.token,
      tokenPreview: notification.token ? notification.token.substring(0, 20) + '...' : 'none',
      dataKeys: Object.keys(notification.data || {})
    });

    // CRITICAL: Send BOTH notification and data payloads for maximum compatibility
    // - notification: Shows system notification in background/killed state
    // - data: Allows custom handling in foreground
    const message = {
      notification: {
        title: notification.title,
        body: notification.body,
      },
      data: {
        title: notification.title,
        body: notification.body,
        ...(notification.data || {}),
      },
      token: Array.isArray(notification.token) ? notification.token[0] : notification.token,
    };

    // Add Android-specific configuration
    message.android = {
      priority: 'high',
    };

    // For incoming calls, add special configuration
    if (notification.data?.action === 'incoming_call') {
      message.android.notification = {
        channelId: 'incoming_calls',
        sound: 'default',
        priority: 'high',
        defaultSound: true,
        defaultVibrateTimings: true,
        tag: notification.data.consultationId,
      };
      
      // Add APNS configuration for iOS
      message.apns = {
        payload: {
          aps: {
            sound: 'default',
            badge: 1,
            'content-available': 1,
          },
        },
      };
      
      console.log('📞 Incoming call notification configured with high priority');
    } else if (notification.data?.action === 'new_message') {
      // For chat messages, use default channel
      message.android.notification = {
        channelId: 'default',
        sound: 'default',
        priority: 'high',
      };
      
      console.log('💬 Chat message notification configured');
    } else {
      // For other notifications
      message.android.notification = {
        channelId: 'default',
        sound: 'default',
      };
    }

    const response = await admin.messaging().send(message);
    console.log('✅ Push notification sent successfully:', response);
    return { success: true, messageId: response };
  } catch (error) {
    console.error('❌ Push notification error:', error);
    console.error('❌ Error code:', error.code);
    console.error('❌ Error message:', error.message);
    
    // Log specific error types
    if (error.code === 'messaging/invalid-registration-token' || 
        error.code === 'messaging/registration-token-not-registered') {
      console.error('❌ Invalid or expired FCM token - removing from DB');
      // Clean up the single invalid token
      try {
        const tokenToRemove = Array.isArray(notification.token) ? notification.token[0] : notification.token;
        if (tokenToRemove) {
          const User = require('../models/User.model');
          const Guest = require('../models/Guest.model');
          await Promise.all([
            User.updateMany({ fcmTokens: tokenToRemove }, { $pull: { fcmTokens: tokenToRemove } }),
            Guest.updateMany({ fcmTokens: tokenToRemove }, { $pull: { fcmTokens: tokenToRemove } }),
          ]);
          console.log('🧹 Removed stale single FCM token from DB');
        }
      } catch (cleanupErr) {
        console.error('⚠️ Failed to clean up invalid token:', cleanupErr.message);
      }
    }
    
    return { success: false, error: error.message };
  }
};

const sendMulticastNotification = async (notification) => {
  if (!firebaseInitialized) {
    console.warn('⚠️ Firebase not initialized. Skipping multicast notification.');
    return { success: false, error: 'Firebase not initialized' };
  }

  try {
    if (!Array.isArray(notification.token)) {
      notification.token = [notification.token];
    }

    // Filter out empty/null tokens upfront
    const validTokens = notification.token.filter(t => t && typeof t === 'string' && t.length > 10);
    if (validTokens.length === 0) {
      console.warn('⚠️ No valid tokens to send multicast notification');
      return { success: false, error: 'No valid tokens' };
    }

    console.log('📤 Preparing to send multicast notification:', {
      title: notification.title,
      body: notification.body?.substring(0, 50),
      tokenCount: validTokens.length,
      dataKeys: Object.keys(notification.data || {})
    });

    const message = {
      notification: {
        title: notification.title,
        body: notification.body,
      },
      data: {
        title: notification.title,
        body: notification.body,
        ...(notification.data || {}),
      },
      tokens: validTokens,
    };

    // Add Android-specific configuration for incoming calls
    if (notification.data?.action === 'incoming_call') {
      message.android = {
        priority: 'high',
        notification: {
          channelId: 'incoming_calls',
          sound: 'default',
          priority: 'high',
          defaultSound: true,
          defaultVibrateTimings: true,
          tag: notification.data.consultationId,
        },
      };
      message.apns = {
        payload: {
          aps: {
            sound: 'default',
            badge: 1,
            'content-available': 1,
          },
        },
      };
      console.log('📞 Multicast incoming call notification configured with high priority');
    } else if (notification.data?.action === 'new_message') {
      message.android = {
        priority: 'high',
        notification: {
          channelId: 'default',
          sound: 'default',
          priority: 'high',
        },
      };
      console.log('💬 Multicast chat message notification configured');
    }

    const response = await admin.messaging().sendEachForMulticast(message);
    console.log(`✅ Multicast notifications sent: ${response.successCount} success, ${response.failureCount} failed`);

    // ── Auto-clean invalid tokens from DB ────────────────────────────────────
    if (response.failureCount > 0) {
      const invalidTokens = [];
      response.responses.forEach((resp, idx) => {
        if (!resp.success) {
          const errCode = resp.error?.code || '';
          const isInvalid =
            errCode === 'messaging/invalid-registration-token' ||
            errCode === 'messaging/registration-token-not-registered' ||
            errCode === 'messaging/invalid-argument';
          if (isInvalid) {
            invalidTokens.push(validTokens[idx]);
          } else {
            console.error(`❌ Failed to send to token[${idx}]:`, resp.error?.message);
          }
        }
      });

      if (invalidTokens.length > 0) {
        console.log(`🧹 Removing ${invalidTokens.length} invalid FCM tokens from DB...`);
        try {
          const User = require('../models/User.model');
          const Guest = require('../models/Guest.model');
          // Pull invalid tokens from both User and Guest collections
          await Promise.all([
            User.updateMany(
              { fcmTokens: { $in: invalidTokens } },
              { $pull: { fcmTokens: { $in: invalidTokens } } }
            ),
            Guest.updateMany(
              { fcmTokens: { $in: invalidTokens } },
              { $pull: { fcmTokens: { $in: invalidTokens } } }
            ),
          ]);
          console.log(`✅ Removed ${invalidTokens.length} stale FCM tokens from DB`);
        } catch (cleanupErr) {
          console.error('⚠️ Failed to clean up invalid tokens:', cleanupErr.message);
        }
      }
    }

    return {
      success: true,
      successCount: response.successCount,
      failureCount: response.failureCount,
    };
  } catch (error) {
    console.error('❌ Multicast notification error:', error);
    console.error('❌ Error code:', error.code);
    console.error('❌ Error message:', error.message);
    return { success: false, error: error.message };
  }
};

module.exports = {
  admin: firebaseInitialized ? admin : null,
  sendPushNotification,
  sendMulticastNotification,
  firebaseInitialized,
};

